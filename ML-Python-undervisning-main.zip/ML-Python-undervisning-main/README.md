# ML-Python-undervisning
Undervisning dag 2
